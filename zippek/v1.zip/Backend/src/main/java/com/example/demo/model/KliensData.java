package com.example.demo.model;

import lombok.Data;

@Data
public class KliensData {

    private String Student_Name;
    private String Student_Email;
    private String Student_Phone;

}
