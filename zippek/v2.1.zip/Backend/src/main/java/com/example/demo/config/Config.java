package com.example.demo.config;

import com.example.demo.model.Contacts;
import com.example.demo.model.Courses;
import com.example.demo.model.Roles;
import com.example.demo.model.Users;
import com.example.demo.repo.ContactsRepo;
import com.example.demo.repo.CoursesRepo;
import com.example.demo.repo.UsersRepo;
import com.example.demo.service.Services;
import com.example.demo.service.TeacherService;
import com.github.javafaker.Faker;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;


@Configuration
@RequiredArgsConstructor
public class Config {

    @Autowired
    private final Services services;

    @Autowired
    private final TeacherService teacherService;

    @Autowired
    private final CoursesRepo coursesRepo;

    @Autowired
    private final UsersRepo usersRepo;

    @Autowired
    private final ContactsRepo contactsRepo;

    //@Bean
    CommandLineRunner commandLineRunner() {
        return args -> {

            LocalDateTime now = LocalDateTime.now();

            Faker faker = new Faker();

            for (int i = 0; i < 25; i++) {

                String username = faker.name().username();
                String password = faker.regexify("(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[@#$%^&+=]).{8,12}");
                Roles role = faker.options().option(Roles.class);

                String email = faker.internet().emailAddress();
                String phone = faker.regexify("(\\+\\d{1,3}[- ]?)?\\d{10}");

                Contacts contact = new Contacts(
                        email,
                        phone
                );

                contactsRepo.save(contact);

                Users user = new Users(
                        username,
                        password,
                        role,
                        contact
                );

                services.register(user);

                if (role == Roles.TEACHER){

                    int k = faker.number().numberBetween(0,5);

                    for (int j = 0; j < k; j++){

                        String courseName = faker.name().title();
                        String courseDescription = faker.lorem().characters(250);
                        Integer capacity = faker.number().numberBetween(1,50);
                        LocalDateTime startDate = faker.date().between(
                                                        Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant()),
                                                        Date.from(LocalDateTime.now().plusMonths(2).atZone(ZoneId.systemDefault()).toInstant())
                                                    ).toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
                        LocalDateTime endDate = faker.date().between(
                                                        Date.from(LocalDateTime.now().plusMonths(2).atZone(ZoneId.systemDefault()).toInstant()),
                                                        Date.from(LocalDateTime.now().plusMonths(3).atZone(ZoneId.systemDefault()).toInstant())
                                                ).toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
                        Users teacher = user;

                        teacherService.saveCourse(
                                new Courses(
                                        courseName,
                                        courseDescription,
                                        capacity,
                                        startDate,
                                        endDate,
                                        teacher
                                )
                        );

                    }

                }

            }



                List<Users> students = usersRepo.findByRole(Roles.STUDENT);
                List<Courses> courses = coursesRepo.findAll();

                for (Users user : students) {

                    int f = faker.number().numberBetween(0, courses.size());

                    for (int j = 0; j < f; j++) {
                        Courses course = courses.get(faker.random().nextInt(courses.size()));
                        courses.remove(course);

                        user.setUser_appointments(courses);
                        usersRepo.save(user);

                        course.setStudentsList(List.of(user));
                        coursesRepo.save(course);
                    }

                }



            Users user1 = new Users(
                        "T",
                        "1234",
                        Roles.TEACHER
                    );

            Users user2 = new Users(
                            "S",
                            "1234",
                            Roles.STUDENT
                    );

            Users user3 = new Users(
                            "A",
                            "1234",
                            Roles.ADMIN
            );

            services.register(user1);
            services.register(user2);
            services.register(user3);



            System.out.println("[Config] Test Data Insertion are done! Started at: " + now + " finished at: " + LocalDateTime.now() + ". Duration: " + getDuration(now, LocalDateTime.now()));

        };
    }

    public Integer getDuration(LocalDateTime start, LocalDateTime end) {
        return (int) ChronoUnit.MINUTES.between(start, end);
    }

}
