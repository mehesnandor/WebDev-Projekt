package com.example.demo.controller;

import com.example.demo.model.KurzusJelentkezesekv1;
import com.example.demo.service.Services;
import lombok.Data;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RequestMapping(path = "api/v1")
@RestController
@Data
public class Controller {

    private final Services services;

    @GetMapping(path = "/get")
    public List<KurzusJelentkezesekv1> getAllCourseAppointments(){
        return services.kurzusokListazasa();
    }

    @GetMapping(path = "/get/my/{email}/{phone}")
    public Optional<KurzusJelentkezesekv1> getKurzusaim(@PathVariable String email, @PathVariable String phone){
        return services.kurzusaim(email, phone);
    }

    @GetMapping(path = "/get/notmy/{email}/{phone}")
    public Optional<KurzusJelentkezesekv1> getNotKurzusaim(@PathVariable String email, @PathVariable String phone){
        return services.nemKurzusaim(email, phone);
    }

    // ----------------------

    @PostMapping(path = "/post/{jelentkezes}")
    public void create(@RequestBody KurzusJelentkezesekv1 kurzus){
        services.kurzusJelentkezes(kurzus);
    }

    // ----------------------

    @PutMapping(path = "/put/{updateDate}")
    public void update(@RequestBody KurzusJelentkezesekv1 kurzus){

    }

    // ----------------------

    @DeleteMapping(path = "/del/{id}")
    public void delete(@PathVariable Long id){
        services.deleteJelentkezes(id);
    }


    //Validation Violation handeling
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleValidationException(MethodArgumentNotValidException ex){
        Map<String, String> errors = new HashMap<>();

        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });

        return errors;
    }

}
