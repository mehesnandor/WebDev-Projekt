package com.example.demo.service;

import com.example.demo.model.Courses;
import com.example.demo.model.Users;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Optional;

public interface StudentsServicesInt {

    //Create
    ResponseEntity<?> makeAnAppointment(String username, Long courseId);

    //Read
    ResponseEntity<List<Courses>> listOfMyCourses(Long studentId);
    ResponseEntity<List<Courses>> listOfNotMyCourses(String username);

    //Delete
    ResponseEntity<?> deleteAppointment(String username, Long courseId);

}
