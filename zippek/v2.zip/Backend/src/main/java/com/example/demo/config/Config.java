package com.example.demo.config;

import com.example.demo.model.Roles;
import com.example.demo.model.Users;
import com.example.demo.service.Services;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
public class Config {

    @Autowired
    private final Services services;

    @Bean
    CommandLineRunner commandLineRunner() {
        return args -> {
            Users user1 = new Users(
                        "T",
                        "1234",
                        Roles.TEACHER
                    );

            Users user2 = new Users(
                            "S",
                            "1234",
                            Roles.STUDENT
                    );

            Users user3 = new Users(
                            "A",
                            "1234",
                            Roles.ADMIN
                    );

            services.register(user1);
            services.register(user2);
            services.register(user3);

        };
    }

}
