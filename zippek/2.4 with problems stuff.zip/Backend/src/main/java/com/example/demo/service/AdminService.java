package com.example.demo.service;

import com.example.demo.model.Contacts;
import com.example.demo.model.Courses;
import com.example.demo.model.Users;
import com.example.demo.repo.ContactsRepo;
import com.example.demo.repo.CoursesRepo;
import com.example.demo.repo.UsersRepo;
import com.example.demo.service.validation.AppUserDetailsValidator;
import com.example.demo.service.validation.CourseDetailsValidator;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Data
@Slf4j
public class AdminService implements AdminsServicesInt{

    @Autowired
    private final TeacherService teacherService;

    @Autowired
    private final AppUserDetailsValidator appUserDetailsValidator;

    @Autowired
    private final CourseDetailsValidator courseDetailsValidator;

    @Autowired
    private final UsersRepo usersRepo;

    @Autowired
    private final ContactsRepo contactsRepo;

    @Autowired
    private final CoursesRepo coursesRepo;

    @Override
    public ResponseEntity<?> createUser(Users user) {

        if (!appUserDetailsValidator.isUserDetailsValid(user)){
            log.error("[Services] Incorect user details! " + user);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }

        contactsRepo.save(user.getContact());
        log.info("[Admin-Service] Contact " + user.getContact() + " created");
        
        log.info("[Admin-Service] User " + user + " created");
        return ResponseEntity.status(HttpStatus.CREATED).body(usersRepo.save(user));
    } // ő tud egyedül nem STUDENT, vagyis ADMIN vagy TEACHER-t létrehozni

    @Override
    public ResponseEntity<?> createCourse(Courses course) {

        if (!courseDetailsValidator.isCourseDetailsValid(course)){
            log.error("[Services] Incorect course details! " + course);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }

        if (usersRepo.findById(course.getTeacher().getUserId()).isEmpty() || course.getTeacher() == null ) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        Users teacher = course.getTeacher();

        course.setTeacher(teacher);
        teacher.setTeacherCourses(List.of(course));

        usersRepo.save(teacher);
        log.info("[Admin-Service] Course " + course + " created to teacher CourseList");

        log.info("[Admin-Service] Teacher " + teacher + " assigned to course " + course);
        return ResponseEntity.status(HttpStatus.CREATED).body(coursesRepo.save(course));
    }

    //---

    @Override
    public ResponseEntity<List<Users>> getAllUsers() {
        log.info("[Admin-Service] Get All Users");
        return ResponseEntity.status(HttpStatus.OK).body(usersRepo.findAll());
    }

    @Override
    public ResponseEntity<List<Courses>> getAllCourses() {
        log.info("[Admin-Service] Get All Courses");
        return ResponseEntity.status(HttpStatus.OK).body(coursesRepo.findAll());
    }

    @Override
    public ResponseEntity<Courses> getCourseById(Long id) {

        if (coursesRepo.findById(id).isEmpty()){
            log.error("[Admin-Service] Course with id " + id + "not found");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        log.info("[Admin-Service] Get Course by ID " + id);
        return ResponseEntity.status(HttpStatus.OK).body(coursesRepo.findById(id).get());

    }

    @Override
    public ResponseEntity<Users> getUserById(Long id) {

        if (usersRepo.findById(id).isEmpty()){
            log.error("[Admin-Service] User with id " + id + " not found");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        log.info("[Admin-Service] Get User by ID " + id);
        return ResponseEntity.status(HttpStatus.OK).body(usersRepo.findById(id).get());
    }

    @Override
    public ResponseEntity<List<Users>> appointmentsForThisCourse(Long courseId) {

        if (coursesRepo.findById(courseId).isEmpty()){
            log.error("[Admin-Service] Course with id " + courseId + " not found");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        log.info("[Teacher-Services] Listing appointments for course with course ID " + courseId);
        return ResponseEntity.status(HttpStatus.CREATED).body(coursesRepo.findById(courseId).get().getStudentsList());
    }

    //---

    @Override
    public ResponseEntity<?> updateUser(Users user) {

        if (user.getContact() != null) {
            if (!appUserDetailsValidator.isContactDetailsValid(user.getContact())){
                log.error("[Services] Incorect contact details! " + user);
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
            }
            log.info("[Services] Registering a new contact for user " + user.getUsername() + " .  The contacts are " + user.getContact());
            contactsRepo.save(user.getContact());
        }

        log.info("[Admin-Service] Contact " + user.getContact() + " updated");

        if (!user.getTeacherCourses().isEmpty()){
            for (Courses course : user.getTeacherCourses()){
                course.setTeacher(user); //mert ha van kurzus hozzá az azt jelenti ő egy tanár
                coursesRepo.save(course);
            }
        }

        user.setPassword(usersRepo.findById(user.getUserId()).get().getPassword());


        log.info("[Admin-Service] User " + user + " updated");
        usersRepo.save(user);

        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @Override
    public ResponseEntity<?> updateCourse(Courses course) {

        if (!courseDetailsValidator.isTeacherLogicValidForUpdate(course)){
            log.error("[Services] Incorect course details! " + course);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }

        Users teacher;

        if (course.getTeacher().getUsername() == null){
            teacher = usersRepo.findById(course.getTeacher().getUserId()).get();
        }else {
            teacher = usersRepo.findByUsername(course.getTeacher().getUsername());
        }

        if(teacher.getUsername() != null && !teacher.getUsername().equals(course.getTeacher().getUsername())){
            teacher.setUsername(course.getTeacher().getUsername());
        }
        if(teacher.getRole() != null && !teacher.getRole().equals(course.getTeacher().getRole())){
            teacher.setRole(course.getTeacher().getRole());
        }

        if(!teacher.getContact().getEmail().equals(course.getTeacher().getContact().getEmail())){
            teacher.getContact().setEmail(course.getTeacher().getContact().getEmail());
        }
        if(!teacher.getContact().getPhone().equals(course.getTeacher().getContact().getPhone())){
            teacher.getContact().setPhone(course.getTeacher().getContact().getPhone());
        }


        contactsRepo.save(teacher.getContact());
        usersRepo.save(teacher);

        course.setTeacher(teacher);

        log.info("[Admin-Service] Course " + course + " updated");

        return ResponseEntity.status(HttpStatus.CREATED).body(coursesRepo.save(course));

    }

    //---

    @Override
    public ResponseEntity<?> deleteUser(Long id) {

        if (usersRepo.findById(id).isEmpty()){
            log.error("[Admin-Service] User with id " + id + " not found");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        Users user = usersRepo.findById(id).get();

        contactsRepo.deleteById(id);

        coursesRepo.deleteAll(user.getTeacherCourses());

        for (Courses course : user.getUser_appointments()){
            teacherService.deleteAppointment(user.getUserId(), course.getCourseId());
        }

        usersRepo.deleteById(id);
        log.info("[Admin-Service] User with ID " + id + " deleted");
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @Override
    public ResponseEntity<?> deleteCourse(Long courseId) {

        log.info("[Admin-Services] Deleting the course with ID " + courseId);

        if(coursesRepo.findById(courseId).isEmpty()){
            log.error("[Teacher-Services] Course with id " + courseId + " not found");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        Courses course = coursesRepo.findById(courseId).get();

        log.info("[Admin-Services] Deleting the course " + course);

        List<Users> students_appointments = appointmentsForThisCourse(courseId).getBody();

        log.info("[Admin-Services] Appointments: " + students_appointments);

        for (Users user : students_appointments) {
            user.getUser_appointments().remove(course);
            usersRepo.save(user);
        }

        log.info("[Admin-Services] Deleting the appointments of course with id " + courseId);

        coursesRepo.delete(course);
        log.info("[Admin-Services] Deleted the course with " + course);
        return ResponseEntity.status(HttpStatus.OK).build();
    }
}
