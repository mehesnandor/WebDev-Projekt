package com.example.demo.controller;

import com.example.demo.model.Courses;
import com.example.demo.model.Users;
import com.example.demo.service.AdminService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/api/v1/management/admin")
@RequiredArgsConstructor
@Slf4j
public class AdminsController {

    @Autowired
    private final AdminService adminService;

    /**
     * Létrehoz egy felhasználót
     * */

    @PostMapping(path = "/create_user")
    public void createUser(@RequestBody Users user) {
        log.info("[Admin-Controller] Create user: " + user.toString());
        adminService.createUser(user);
    }

    /**
     * Létrehoz egy kurzust
     * */

    @PostMapping(path = "/create_course/{tid}")
    public void createCourse(@RequestBody Courses course, @PathVariable("tid") Long id) {
        log.info("[Admin-Controller] Create course: " + course);
        adminService.createCourse(course);
    }

    //---

    /**
     * Listázza az összes felhasználót
     * */

    @GetMapping(path = "/all_users")
    public List<Users> getAllUsers() {
        log.info("[Admin-Controller] Get all users");
        return adminService.getAllUsers();
    }

    /**
     * Létrehoz az összes kurzust
     * */

    @GetMapping(path = "/all_courses")
    public List<Courses> getAllCourses() {
        log.info("[Admin-Controller] Get all courses");
        return adminService.getAllCourses();
    }

    /**
     * Listáz egy kurzust
     * */

    @GetMapping(path = "/course/{cid}")
    public ResponseEntity<Courses> getCourseById(@PathVariable("cid") Long id) {
        log.info("[Admin-Controller] Get course by id: " + id);
        return ResponseEntity.status(HttpStatus.OK).body(adminService.getCourseById(id));
    }

    /**
     * Listáz egy felhasználót
     * */

    @GetMapping(path = "/user/{uid}")
    public ResponseEntity<Users> getUserById(@PathVariable("uid") Long id) {
        log.error("[Admin-Controller] User with id " + id + "not found");
        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

    //---

    /**
     * Frissiti egy felhasználó adatait
     * */

    @PutMapping(path = "/user_update")
    public void updateUser(@RequestBody Users user) {
        log.info("[Admin-Controller] Update user: " + user.toString());
        adminService.updateUser(user);
    }

    /**
     * Frissiti egy kurzus adatait
     * */

    @PutMapping(path = "/course_update")
    public void updateCourse(@RequestBody Courses course) {
        log.info("[Admin-Controller] Update course: " + course.toString());
        adminService.updateCourse(course);
    }

    //---

    /**
     * Töröl egy felhasználót
     * */

    @DeleteMapping(path = "/user/delete/{uid}")
    public void deleteUser(@PathVariable("uid") Long id) {
        log.info("[Admin-Controller] Delete user by id: " + id);

        adminService.deleteUser(id);
    }

    /**
     * Töröl egy kurzust
     * */

    @DeleteMapping(path = "/course/delete/{cid}")
    public void deleteCourse(@PathVariable("cid") Long id) {
        log.info("[Admin-Controller] Delete course by id: " + id);
        adminService.deleteCourse(id);
    }

}
