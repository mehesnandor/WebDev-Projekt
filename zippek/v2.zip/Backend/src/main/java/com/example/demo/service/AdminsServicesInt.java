package com.example.demo.service;

import com.example.demo.model.Courses;
import com.example.demo.model.Users;

import java.util.List;

public interface AdminsServicesInt {

    //Create
    void createUser(Users user);
    void createCourse(Courses course);

    //Read
        //Ezeket old majd meg pagerrel!!!
    List<Users> getAllUsers();
    List<Users> getAllCourses();
    Courses getCourseById(Long id);
    Users getUserById(Long id);

    //Update
    void updateUser(Users user);
    void updateCourse(Courses course);

    //Delete
    void deleteUser(Long id);
    void deleteCourse(Long id);

}
