package com.example.demo.service;

import com.example.demo.model.Courses;
import com.example.demo.model.Users;
import com.example.demo.repo.ContactsRepo;
import com.example.demo.repo.CoursesRepo;
import com.example.demo.repo.UsersRepo;
import com.example.demo.service.validation.AppUserDetailsValidator;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
@Data
@Slf4j
public class AdminService implements AdminsServicesInt{

    @Autowired
    private final AppUserDetailsValidator appUserDetailsValidator;

    @Autowired
    private final UsersRepo usersRepo;

    @Autowired
    private final ContactsRepo contactsRepo;

    @Autowired
    private final CoursesRepo coursesRepo;

    @Override
    public void createUser(Users user) {

        if (!appUserDetailsValidator.isUserDetailsValid(user)){
            log.error("[Services] Incorect user details! " + user);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Incorect user details!");
        }

        contactsRepo.save(user.getContact());
        log.info("[Admin-Service] Contact " + user.getContact() + " created");

        usersRepo.save(user);
        log.info("[Admin-Service] User " + user + " created");

    }

    @Override
    public void createCourse(Courses course) {


        if (usersRepo.findById(course.getTeacher().getUserId()).isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found");
        }

        Users teacher = course.getTeacher();

        course.setTeacher(teacher);
        teacher.setTeacherCourses(List.of(course));

        usersRepo.save(teacher);
        log.info("[Admin-Service] Course " + course + " created to teacher CourseList");
        coursesRepo.save(course);
        log.info("[Admin-Service] Teacher " + teacher + " assigned to course " + course);
    }

    //---

    @Override
    public List<Users> getAllUsers() {
        log.info("[Admin-Service] Get All Users");
        return usersRepo.findAll();
    }

    @Override
    public List<Courses> getAllCourses() {
        log.info("[Admin-Service] Get All Courses");
        return coursesRepo.findAll();
    }

    @Override
    public Courses getCourseById(Long id) {

        if (!coursesRepo.findById(id).isEmpty()){
            log.error("[Admin-Service] Course with id " + id + "not found");
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Course with id " + id + " not found");
        }

        log.info("[Admin-Service] Get Course by ID " + id);
        return coursesRepo.findById(id).get();
    }

    @Override
    public Users getUserById(Long id) {

        if (usersRepo.findById(id).isEmpty()){
            log.error("[Admin-Service] User with id " + id + " not found");
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User with id " + id + " not found");
        }

        log.info("[Admin-Service] Get User by ID " + id);
        return usersRepo.findById(id).get();
    }

    @Override
    public List<Users> appointmentsForThisCourse(Long courseId) {

        if (coursesRepo.findById(courseId).isEmpty()){
            log.error("[Admin-Service] Course with id " + courseId + " not found");
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Course with id " + courseId + " not found");
        }

        log.info("[Teacher-Services] Listing appointments for course with course ID " + courseId);
        return coursesRepo.findById(courseId).get().getStudentsList();
    }

    //---

    @Override
    public void updateUser(Users user) {

        if (!appUserDetailsValidator.isUserDetailsValid(user)){
            log.error("[Services] Incorect user details! " + user);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Incorect user details!");
        }

        contactsRepo.save(user.getContact());
        log.info("[Admin-Service] Contact " + user.getContact() + " updated");
        usersRepo.save(user);
        log.info("[Admin-Service] User " + user + " updated");
    }

    @Override
    public void updateCourse(Courses course) {
        coursesRepo.save(course);
        log.info("[Admin-Service] Course " + course + " updated");
    }

    //---

    @Override
    public void deleteUser(Long id) {
        usersRepo.deleteById(id);
        log.info("[Admin-Service] User with ID " + id + " deleted");
    }

    @Override
    public void deleteCourse(Long courseId) {
        log.info("[Admin-Services] Deleting the course with ID " + courseId);

        Courses course = coursesRepo.findById(courseId)
                .orElseThrow(() -> {
                    log.error("[Teacher-Services] Course with id " + courseId + " not found");
                    return new RuntimeException("Course not found");
                });

        log.info("[Admin-Services] Deleting the course " + course);

        List<Users> students_appointments = appointmentsForThisCourse(courseId);

        log.info("[Admin-Services] Appointments: " + students_appointments);

        for (Users user : students_appointments) {
            user.getUser_appointments().remove(course);
            usersRepo.save(user);
        }

        log.info("[Admin-Services] Deleting the appointments of course with id " + courseId);

        coursesRepo.delete(course);

        log.info("[Admin-Services] Deleted the course with " + course);
    }
}
