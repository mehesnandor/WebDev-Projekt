package com.example.demo.service;


import com.example.demo.model.KurzusJelentkezesekv1;
import com.example.demo.repo.KurzusJelentkezesekv1Repo;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@Data
@Slf4j
public class Services implements ServicesInterface {

    private final KurzusJelentkezesekv1Repo kRepo;

    //CRUD
    // Majd ird át őket JPQL-re

    // ------------------------------Create------------------------------//

    @Override
    public void kurzusJelentkezes(KurzusJelentkezesekv1 kjv1) { //Az API-nál Hard Code-olom a kurzusok adatait
        //--Meg kell vizsgálni van e még hely?
        //--Meg kell vizsgálni jelentkezett-e már azzal az email és phone-nal az a felhasználó. Ha igen akkor hiba
        //L

        if (kRepo.findById(kjv1.getC_A_ID()).isPresent() /*Kapacitás vizsgálat ide*/) {
            log.error("Sajnálom, erre a kurzusra már jelentkeztél. Kérlek ne idegesisd a tanáraidat!");
        }else{
            kRepo.save(kjv1);
        }
    }

   // -------------------------------Read-------------------------------//

    @Override
    public List<KurzusJelentkezesekv1> kurzusokListazasa() {
        return kRepo.findAll();
    }

    @Override
    public Optional<KurzusJelentkezesekv1> kurzusaim(String email, String phone) {
        return kRepo.findByEmailAndPhone(email, phone);
    }

    @Override
    public Optional<KurzusJelentkezesekv1> nemKurzusaim(String email, String phone) {
        return kRepo.findByNotEmailAndNotPhone(email, phone);
    }

    // -------------------------------Update-----------------------------//

    @Override
    public void updateJelentkezes(Long id, String name, String email, String phone) {
        //--Csak ha létezik updatelünk, eggyébként hiba

        boolean ifitsexists = kRepo.existsById(id);
        //boolean ifitsexists = kRepo.findById(id).isPresent();

        if (ifitsexists) {
            Optional<KurzusJelentkezesekv1> jelentkezes = kRepo.findById(id);
            jelentkezes.ifPresent(jel -> {
                        jel.setStudent_Name(name);
                        jel.setStudent_Email(email);
                        jel.setStudent_Phone(phone);
                        kRepo.save(jel);
                    }
            );
            log.info("Sikeres Update");
        }else{
            log.error("Hiba, Nem létezik az Update-elni kivánt jelentkezés");
        }
    }

    // ------------------------------Delete------------------------------//

    @Override
    public void deleteJelentkezes(Long id) {
        kRepo.deleteById(id);
        log.info("Jelentkezését (id = " + id + ") sikeresen töröltük.");
    }

    // ------------------------------Other-------------------------------//



}
