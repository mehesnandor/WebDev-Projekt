package com.example.demo.service;

import com.example.demo.model.Courses;
import com.example.demo.model.Users;
import com.example.demo.repo.CoursesRepo;
import com.example.demo.repo.UsersRepo;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
@RequiredArgsConstructor
@Slf4j
public class StudentService implements StudentsServicesInt{

    @Autowired
    private TeacherService teacherService;

    @Autowired
    private final CoursesRepo coursesRepo;

    @Autowired
    private final UsersRepo usersRepo;

    /**
     * Egy felhasználóhoz rendel egy kurzust
     * */

    @Override
    public ResponseEntity<?> makeAnAppointment(String username, Long courseId) {

        if (coursesRepo.findById(courseId).isEmpty()){
            log.error("[Student-Service] Course not found");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        Courses course = coursesRepo.findById(courseId).get();
        Users student = usersRepo.findByUsername(username); // Feltételezzük, hogy létezik, hiszen be tudott jelentkezni, hogy használni tudja ezt a funkciót

        log.info("[Student-Service] Making an appointment");
        if (!student.getUser_appointments().contains(course)) { // Hogy ne szerepeljen egy kurzus többször

            if (course.getCapacity() < teacherService.appointmentsForThisCourse(course.getCourseId()).getBody().size() + 1){ // ne lépje át a max kapacitást
                log.error("[Student-Controller] Out of capacity. You were late. Try it next time or with other courses!");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
            }

            student.getUser_appointments().add(course);
            course.getStudentsList().add(student);

            coursesRepo.save(course);
            usersRepo.save(student);

            return ResponseEntity.status(HttpStatus.OK).build();

        }

        log.error("Course (" + course + ") already added to student");
        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();

    }

    /**
     * Listázza a tanulóhoz tartozó kurzusokat
     * */

    @Override
    public ResponseEntity<List<Courses>> listOfMyCourses(Long studentId) {

        if (usersRepo.findById(studentId).isEmpty()){
            log.error("[Student-Service] Course not found");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        log.info("[Student-Service] Listing My Courses");
        return ResponseEntity.status(HttpStatus.OK).body(usersRepo.findById(studentId).get().getUser_appointments());
    }

    /**
     * Listázza a nem ahoz a tanulóhoz tartozó kurzusokat
     * */

    @Override
    public ResponseEntity<List<Courses>> listOfNotMyCourses(String username) {
        log.info("[Student-Service] Listing Not My Courses");
        return ResponseEntity.status(HttpStatus.OK).body(coursesRepo.findByStudentsListNotContains(usersRepo.findByUsername(username))); // Vajon ez igy működik???
    }

    @Override
    public ResponseEntity<?> deleteAppointment(String username, Long courseId) {

        if (coursesRepo.findById(courseId).isEmpty()){
            log.error("[Student-Service] Course not found");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        Courses course = coursesRepo.findById(courseId).get();
        Users student = usersRepo.findByUsername(username);

        log.info("[Student-Service] Deleting an appointment with id: " + course + " and student: " + student);

        student.getUser_appointments().remove(course);
        course.getStudentsList().remove(student);

        usersRepo.save(student);
        coursesRepo.save(course);
        return ResponseEntity.status(HttpStatus.OK).build();
    }
}
