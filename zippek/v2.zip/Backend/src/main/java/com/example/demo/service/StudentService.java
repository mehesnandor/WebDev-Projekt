package com.example.demo.service;

import com.example.demo.model.Courses;
import com.example.demo.repo.CoursesRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService implements StudentsServicesInt{

//    @Autowired
//    priavte final CoursesRepo coursesRepo;
//    Hogzan kell itt több táblás kapcsoltahoz mindhez be importálni cucc izé



    @Override
    public void makeAnAppointment(Long studentId, Long courseId) {
        //JPA Course!!!!!
    }

    @Override
    public List<Courses> listOfMyCourses(Long studentId) {
        return List.of();
    }

    @Override
    public List<Courses> listOfNotMyCourses(Long studentId) {
        return List.of();
    }

    @Override
    public void deleteAppointment(Long studentId, Long courseId) {

    }
}
