package com.example.demo.service;

import com.example.demo.model.Courses;

import java.util.List;

public interface StudentsServicesInt {

    //Create
    void makeAnAppointment(Long studentId, Long courseId);

    //Read
    List<Courses> listOfMyCourses(Long studentId);
    List<Courses> listOfNotMyCourses(Long studentId);

    //Delete
    void deleteAppointment(Long studentId, Long courseId);

}
