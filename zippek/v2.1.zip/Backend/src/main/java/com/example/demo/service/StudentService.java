package com.example.demo.service;

import com.example.demo.model.Courses;
import com.example.demo.model.Users;
import com.example.demo.repo.CoursesRepo;
import com.example.demo.repo.UsersRepo;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
@RequiredArgsConstructor
@Slf4j
public class StudentService implements StudentsServicesInt{

    @Autowired
    private TeacherService teacherService;

    @Autowired
    private final CoursesRepo coursesRepo;

    @Autowired
    private final UsersRepo usersRepo;

    /**
     * Egy felhasználóhoz rendel egy kurzust
     * */

    @Override
    public void makeAnAppointment(String username, Long courseId) {

        if (coursesRepo.findById(courseId).isEmpty()){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Course with ID " + courseId + " not found");
        }

        Courses course = coursesRepo.findById(courseId).get();
        Users student = usersRepo.findByUsername(username);

        log.info("[Student-Service] Making an appointment");
        if (!student.getUser_appointments().contains(course)) {

            if (course.getCapacity() < teacherService.appointmentsForThisCourse(course.getCourseId()).size() + 1){
                log.error("[Student-Controller] Out of capacity. You were late. Try it next time or with other courses!");
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "[Student-Controller] Out of capacity. You were late. Try it next time or with other courses!");
            }

            student.getUser_appointments().add(course);
            course.getStudentsList().add(student);

            coursesRepo.save(course);
            usersRepo.save(student);

        } else {

            log.error("Course (" + course + ") already added to student");
            throw new RuntimeException("Course already added to student");

        }
    }

    /**
     * Listázza a tanulóhoz tartozó kurzusokat
     * */

    @Override
    public Optional<Courses> listOfMyCourses(Long studentId) {
        log.info("[Student-Service] Listing My Courses");
        return coursesRepo.findById(studentId);
    }

    /**
     * Listázza a nem ahoz a tanulóhoz tartozó kurzusokat
     * */

    @Override
    public List<Courses> listOfNotMyCourses(String username) {
        log.info("[Student-Service] Listing Not My Courses");
        return coursesRepo.findByStudentsListNotContains(usersRepo.findByUsername(username));
    }

    @Override
    public void deleteAppointment(String username, Long courseId) {

        if (coursesRepo.findById(courseId).isEmpty()){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Course with ID " + courseId + " not found");
        }

        Courses course = coursesRepo.findById(courseId).get();
        Users student = usersRepo.findByUsername(username);

        log.info("[Student-Service] Deleting an appointment with id: " + course + " and student: " + student);

        student.getUser_appointments().remove(course);
        course.getStudentsList().remove(student);

        usersRepo.save(student);
        coursesRepo.save(course);

    }
}
