package com.example.demo.model;


import jakarta.persistence.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.*;
import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

@ToString
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

@Entity(name = "courses")
@Table(name = "Courses")
public class Courses {

    @Valid

    @Id
    @SequenceGenerator(
            name = "courses_seq",
            sequenceName = "courses_seq",
            allocationSize = 1
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "courses_seq"
    )

    @Column(
            name = "courseId",
            nullable = false
    )
    private Long courseId;

    @Column(
            name = "courseName",
            nullable = false,
            unique = true
    )
    @NotBlank(message = "coursename can not be blank")
    private String courseName;

    @Column(name = "courseDescription")
    @Size(min = 0, max = 255)
    private String courseDescription;

    @Column(
            name = "capacity",
            nullable = false
    )
    @Range(min = 1, max = 50, message = "Capacity must be between 1 and 50")
    @NotNull(message = "capacity can not be blank")
    private Integer capacity;

    @Column(
            name = "startDate",
            nullable = false
            // Rá ér később is -- Nem létezhet a DB-en a now() előtti időpont, vagyis valahogy folyton törölnünk kell azokat időnként
    )
    @FutureOrPresent(message = "Csak jelen és jövőbeli időket adhatsz meg")
    private LocalDate startDate;

    @Column(
            name = "endDate",
            nullable = false
    )
    @FutureOrPresent(message = "Csak jelen és jövőbeli időket adhatsz meg")
    private LocalDate endDate;

    @Transient
    // | endDate - startDate |
    private Integer duration; // Percekben

    public Integer getDuration() {
        return startDate != null && endDate != null
                ? (int) ChronoUnit.MINUTES.between(startDate, endDate)
                : null;
    }

    // FKs

    @ManyToOne
    @JoinColumn(name = "teacher_id")
    private Users teacher_id;

    @ManyToMany(mappedBy = "user_appointments")
    private List<Users> studentsList;
}
