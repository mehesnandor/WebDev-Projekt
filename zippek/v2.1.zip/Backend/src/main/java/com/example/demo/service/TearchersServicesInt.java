package com.example.demo.service;

import com.example.demo.model.Courses;
import com.example.demo.model.Users;

import java.util.List;
import java.util.Optional;

public interface TearchersServicesInt {

    //Create
    Courses saveCourse(Courses course);

    //Read
    Courses detailsOfACourse(Long courseId);
    List<Users> appointmentsForThisCourse(Long courseId);
    List<Courses> listOfMyCourses(Long teacherId);

    //Update
    void updateThisCourse(Courses course);

    //Delete
    void deleteCourse(Long courseId);
    void deleteAppointment(Long courseId, Long studentId);

}
