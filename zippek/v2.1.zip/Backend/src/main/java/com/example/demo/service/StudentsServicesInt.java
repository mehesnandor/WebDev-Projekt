package com.example.demo.service;

import com.example.demo.model.Courses;
import com.example.demo.model.Users;

import java.util.List;
import java.util.Optional;

public interface StudentsServicesInt {

    //Create
    void makeAnAppointment(String username, Long courseId);

    //Read
    Optional<Courses> listOfMyCourses(Long studentId);
    List<Courses> listOfNotMyCourses(String username);

    //Delete
    void deleteAppointment(String username, Long courseId);

}
