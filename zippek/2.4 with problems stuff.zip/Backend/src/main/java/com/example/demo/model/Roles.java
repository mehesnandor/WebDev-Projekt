package com.example.demo.model;

public enum Roles {
    ROLE_STUDENT, ROLE_TEACHER, ROLE_ADMIN
}
