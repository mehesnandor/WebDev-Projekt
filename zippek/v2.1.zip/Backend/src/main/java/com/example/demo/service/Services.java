package com.example.demo.service;


import com.example.demo.model.Users;
import com.example.demo.repo.ContactsRepo;
import com.example.demo.repo.UsersRepo;
import com.example.demo.security.JWTService;
import com.example.demo.service.validation.AppUserDetailsValidator;
import io.swagger.v3.oas.annotations.Operation;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
@Data
@Slf4j
public class Services implements ServicesInterface {

    @Autowired
    private final UsersRepo usersRepo;

    @Autowired
    private final ContactsRepo contactsRepo;

    @Autowired
    private final AuthenticationManager authManager;

    @Autowired
    private final JWTService jwtService;

    @Autowired
    private final AppUserDetailsValidator appUserDetailsValidator;

    /**
     * Felhasználó regisztrálása
     * */

    @Override
    public Users register(Users user){

        if (!appUserDetailsValidator.isUserDetailsValid(user)){
            log.error("[Services] Incorect user details! " + user);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Incorect user details!");
        }

        user.setPassword(new BCryptPasswordEncoder(12).encode(user.getPassword()));
        log.info("[Services] Registering a new contact for user " + user.getUsername() + " .  The contacts are " + user.getContact());
        contactsRepo.save(user.getContact());
        log.info("[Services] Registering a new user " + user);
        return usersRepo.save(user);
    }

    /**
     * Felhasználói adatok lekérdezése
     * */

    @Override
    public Users getUserDataByUsername(String username) {
        if (usersRepo.existsByUsername(username)) {
            log.info("[Services] Get User Data By Username" + username);
            return usersRepo.findByUsername(username);
        }
        log.error("[Controller] User Data for " + username + " not found");
        throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Username " + username + " not found!");
    }

    /**
     * Felhasználó frissitése
     * */

    @Override
    public Users updateUserData(Users user) {

        if (usersRepo.findById(user.getUserId()).isEmpty()){
            log.error("[Services] User you specified " + user + " not found");
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "[Services] User you specified not found");
        }

        if (!appUserDetailsValidator.isUserDetailsValid(user)){
            log.error("[Services] Incorect user details! " + user);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Incorect user details for update!");
        }

        log.info("[Services] Updating user data for " + usersRepo.findById(user.getUserId()) + " to " + user);

        user.setPassword(usersRepo.findById(user.getUserId()).get().getPassword());

        log.info("[Services] Registering a new contact for user " + user.getUsername() + " .  The contacts are " + user.getContact());
        contactsRepo.save(user.getContact());

        log.info("[Services] Registering a new user " + user);
        return usersRepo.save(user);
    }

    /**
     * Felhasználó törlése
     * */

    @Override
    public void deleteUserAccount(String username) {
        if (usersRepo.existsByUsername(username)) {
            contactsRepo.delete(usersRepo.findByUsername(username).getContact());
            log.info("[Services] Deleted user: " + username);
            usersRepo.delete(usersRepo.findByUsername(username));
        }else{
            log.info("[Services] User Data for " + username + "not found");
        }
    }

    @Operation(
            summary = "Felhasználói adatok ellenőrzése bejelentkezéshez",
            description = "Flehasználó név és jelszó megadásával az authentifikációs kezelő eleinte httpBasic mód megpróbálja authentifikálni a felhasználót, amenyiben nincsen JWT Tokene (Ez a rész a SecurityConfig file JWTFilter részénél található)" +
                    ". Sikeres authentifikáció esetén generál egy JWT Tokent, amit vissza ad."
    )

    /**
     *  Felhasználói adatok ellenőrzése bejelentkezéshez
     *  Flehasználó név és jelszó megadásával az authentifikációs kezelő eleinte httpBasic mód megpróbálja authentifikálni a felhasználót, amenyiben nincsen JWT Tokene (Ez a rész a SecurityConfig file JWTFilter részénél található). Sikeres authentifikáció esetén generál egy JWT Tokent, amit vissza ad.
     * */

    public String verify(Users user){

        log.info("[Services] Verifying user data: " + user.toString());

        Authentication auth = authManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        user.getUsername(),
                        user.getPassword()
                )
        );

        if (auth.isAuthenticated()){
            log.info("[Services] Is Authentificated:  " + auth.isAuthenticated());
            log.info("[Services] Principals: " + auth.getPrincipal() + " Username: " + user.getUsername());
            log.info("[Services] Sikeres JWT Token authentifikáció");
            return jwtService.generateToken(user.getUsername());
        }

        log.error("[Services] Sikertelen authentifikáció");
        return "Field to authenticate";

    }

}
