package com.example.demo.service;


import com.example.demo.model.Users;
import com.example.demo.repo.UsersRepo;
import com.example.demo.security.JWTService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@Data
@Slf4j
public class Services implements ServicesInterface {

    @Autowired
    private final UsersRepo usersRepo;

    @Autowired
    private final AuthenticationManager authManager;

    @Autowired
    private final JWTService jwtService;

    public Users register(Users user){
        //Validation have to be implemented
        user.setPassword(new BCryptPasswordEncoder(12).encode(user.getPassword()));
        return usersRepo.save(user);
    }

    public String verify(Users user){
        System.out.println("Services' user data: " + user.toString());
        Authentication auth = authManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        user.getUsername(),
                        user.getPassword()
                )
        );

        if (auth.isAuthenticated()){
            System.out.println("Is Authentificated:  " + auth.isAuthenticated());
            System.out.println("Principals" + auth.getPrincipal() + " Username> " + user.getUsername());
            return jwtService.generateToken(user.getUsername());  // Syerintem ezzel lessy a baj, i guesssssssssssss
        }

        return "Field to validate. No JWT Token";

    }

}
