package com.example.demo.service;

public interface ServicesInterface {

    //LogIn - Verifivation

    //Your Data Manager - Read, Update, Delete

        //contactAndUserData myData(Long id);
        //void updateMyData(Long id, User user->vagy nem tudom, ird le minden propertyara egz eljarast es kesz)
        //void deleteMe(Long id); =>Hogzan törlünk, úgy hogy a többi hozzá kapcsolódó táblákban lévő sorok is eltörlődjenek?

    //Register - User Creation
        //Hogyan Insertálunk, hogy a Courses és a User táblát össze kapcsolva insertáljunk???































    //CRUD


    //Create

    //Read

    //Update

    //Delete


}
