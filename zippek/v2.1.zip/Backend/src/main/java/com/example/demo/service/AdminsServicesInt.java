package com.example.demo.service;

import com.example.demo.model.Courses;
import com.example.demo.model.Users;

import java.util.List;

public interface AdminsServicesInt {

    //Create
    void createUser(Users user);
    void createCourse(Courses course);

    //Read
    //Ezeket old majd meg pagerrel!!! meg a többi service-nél is
    List<Users> getAllUsers();
    List<Courses> getAllCourses();
    Courses getCourseById(Long id);
    Users getUserById(Long id);
    List<Users> appointmentsForThisCourse(Long courseId);

    //Update
    void updateUser(Users user);
    void updateCourse(Courses course);

    //Delete
    void deleteUser(Long id);
    void deleteCourse(Long id);

}
