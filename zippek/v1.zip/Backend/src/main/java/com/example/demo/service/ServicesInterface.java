package com.example.demo.service;

import com.example.demo.model.KurzusJelentkezesekv1;

import java.util.List;
import java.util.Optional;

public interface ServicesInterface {

    //CRUD - Only Student View

    //Create
    public void kurzusJelentkezes(KurzusJelentkezesekv1 kjv1);
    //Read
    public List<KurzusJelentkezesekv1> kurzusokListazasa();
    public Optional<KurzusJelentkezesekv1> kurzusaim(String email, String phone);
    public Optional<KurzusJelentkezesekv1> nemKurzusaim(String email, String phone);
    //Update
    public void updateJelentkezes(Long id, String name, String email, String phone);
    //Delete
    public void deleteJelentkezes(Long id);

}
