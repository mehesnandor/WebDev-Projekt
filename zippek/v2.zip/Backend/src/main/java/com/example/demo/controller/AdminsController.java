package com.example.demo.controller;


import com.example.demo.model.Users;
import com.example.demo.repo.UsersRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(path = "api/v1/management/admin")
@RequiredArgsConstructor
public class AdminsController {

    @Autowired
    private final UsersRepo usersRepo;

    @GetMapping(path = "/users")
    public List<Users> allusers(){
        System.out.println("Controller got a user data: " + usersRepo.findAll());
        return usersRepo.findAll();
    }

}
