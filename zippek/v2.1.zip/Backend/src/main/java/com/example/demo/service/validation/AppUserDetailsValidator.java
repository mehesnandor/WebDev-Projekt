package com.example.demo.service.validation;

import com.example.demo.model.Users;
import com.example.demo.repo.ContactsRepo;
import com.example.demo.repo.UsersRepo;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Data
@Slf4j
@Service
public class AppUserDetailsValidator {

    @Autowired
    private final UsersRepo usersRepo;

    @Autowired
    private final ContactsRepo contactsRepo;

    public boolean isUserDetailsValid(Users user){

        if (usersRepo.findByUsername(user.getUsername()) != null) {
            log.error("[AppUserDetailsValidator] User " + user.getUsername() + " already exists");
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "[AppUserDetailsValidator] User " + user.getUsername() + " already exists");
        }

        if (!PasswordValidator.isValidPassword(user.getPassword())){
            log.error("[AppUserDetailsValidator] Error, password is incorrect: " + user.getPassword());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "[AppUserDetailsValidator] Error, password is incorrect");
        }

        if (contactsRepo.findByEmail(user.getContact().getEmail()) != null) {
            log.error("[AppUserDetailsValidator] Error, email exists: " + user.getContact().getEmail());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "[AppUserDetailsValidator] Error, email exists");
        }

        if (contactsRepo.findByPhone(user.getContact().getPhone()) != null) {
            log.error("[AppUserDetailsValidator] Error, phone exists: " + user.getContact().getPhone());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "[AppUserDetailsValidator] Error, phone exists");
        }

        return true;
    }

}
