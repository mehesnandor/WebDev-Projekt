package com.example.demo.controller;

import com.example.demo.model.Users;
import com.example.demo.service.Services;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@Data
public class Controller {

    @Autowired
    private final Services services;

    @PostMapping(path = "/register")
    public ResponseEntity<?> registration(@RequestBody Users user){
        return ResponseEntity.status(HttpStatus.CREATED).body(services.register(user));
    }

    @PostMapping(path = "/login")
    public String login(@RequestBody Users user){
        System.out.println("Controller got a user data: " + user.toString());
        return services.verify(user);
    }



    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleValidationExceptions(
            MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        return errors;
    }
}
