package com.example.demo.model;

import jakarta.persistence.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

@Entity(name = "users")
@Table(name = "Users")
public class Users {

    @Valid

    @Id
    @SequenceGenerator(
            name = "users_seq",
            sequenceName = "users_seq",
            allocationSize = 1
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "users_seq"
    )

    @Column(
            name = "userId",
            nullable = false,
            unique = true
    )
    private Long userId;

    @Column(
            name = "userName",
            nullable = false,
            unique = true
    )
    @NotBlank(message = "firstname can not be blank")
    private String username;

    @Column(
            name = "password",
            nullable = false
    )
    @NotBlank(message = "password can not be blank")
    private String password;

    @Column(
            name = "role",
            nullable = false
    )
    @Enumerated(EnumType.STRING)
    private Roles role;

    public Users(String username, String password, Roles role) {
        this.username = username;
        this.password = password;
        this.role = role;
    }

    public Users(String username, String password) {
        this.username = username;
        this.password = password;
        this.role = Roles.STUDENT;
    }

    public Users(String username, String password, Roles role, Contacts contacts) {
        this.username = username;
        this.password = password;
        this.role = role;
        this.contact = contacts;
    }

    public Users(String username, String password, Contacts contacts) {
        this.username = username;
        this.password = password;
        this.role = Roles.STUDENT;
        this.contact = contacts;
    }

    // FKs

    @OneToOne
    @JoinColumn(name = "contact_id")
    private Contacts contact;

    @OneToMany(mappedBy = "teacher")
    private List<Courses> teacherCourses;

    @ManyToMany
    @JoinTable(
        name = "appointments_to_courses",
        joinColumns = @JoinColumn(name = "userId"),
        inverseJoinColumns = @JoinColumn(name = "courseId")
    )
    private List<Courses> user_appointments;

}
