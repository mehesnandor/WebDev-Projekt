package com.example.demo.controller;


import com.example.demo.model.Courses;
import com.example.demo.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "api/v1/student")
@RequiredArgsConstructor
public class StudentsController{

    @Autowired
    private final StudentService studentService;

    /**
    * A Student csak a kurzusokkal tudnak interaktálni.
    */

    /**Tudnak jelentkezni kurzusokra*/
    @PostMapping(path = "/create")
    void makeAnAppointment(Long studentId, Long courseId){
        //cucc
    }

    /**Listázni a kurzusaikat*/
    @GetMapping(path = "/mycourses")
    List<Courses> listOfMyCourses(Long studentId){
        //cucc
        return null;
    }

    /**Listázni a további kurzusokat, amikre még nincsen jelentkezése*/
    @GetMapping(path = "/notmycourses")
    public String/*List<Courses>*/ listOfNotMyCourses(Long studentId){
        System.out.println("Student Get works well");
        return "Get works well";
    }

    /**Törli a jelentkezést*/
    @DeleteMapping(path = "/delete")
    void deleteAppointment(Long studentId, Long courseId){
        //cucc
    }

}
