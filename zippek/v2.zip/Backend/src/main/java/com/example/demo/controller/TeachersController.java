package com.example.demo.controller;


import com.example.demo.model.Courses;
import com.example.demo.model.Users;
import com.example.demo.service.TeacherService;
import com.example.demo.service.TearchersServicesInt;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping(path = "/api/v1/management/teacher")
@RequiredArgsConstructor
public class TeachersController{

    @Autowired
    private final TeacherService teacherService;



    @PostMapping(path = "/create_course")
    public ResponseEntity<Courses> saveCourse(@RequestBody Courses course) {
        teacherService.saveCourse(course);
        URI uri = URI.create(ServletUriComponentsBuilder.fromCurrentContextPath().path("/api/v1/management/teacher/create_course").toUriString());
        return ResponseEntity.created(uri).body(course);
    }

    //----

    @GetMapping(path = "/appointmentslist/{cid}")
    public ResponseEntity<List<Users>> appointmentsForThisCourse(@PathVariable("cid") Long courseId) {
        return ResponseEntity.ok().body(teacherService.appointmentsForThisCourse(courseId));
    }

    @GetMapping(path = "/mycourses/{tid}")
    public ResponseEntity<List<Courses>> listOfMyCourses(@PathVariable("tid") Long teacherId) {
        return ResponseEntity.ok().body(teacherService.listOfMyCourses(teacherId));
    }

    @GetMapping(path = "/details/{cid}")
    public ResponseEntity<Courses> detailsOfACourse(@PathVariable("cid") Long courseId) {
        return ResponseEntity.ok().body(teacherService.detailsOfACourse(courseId));
    }

    //----

    @PutMapping(path = "/update/{cid}")
    public void updateThisCourse(@PathVariable("cid") Long courseId,@RequestBody Courses course) {
        teacherService.updateThisCourse(courseId, course);
    }

    //----

    @DeleteMapping(path = "/delete/course/{id}")
    public void deleteCourse(@PathVariable("id") Long courseId) {
        teacherService.deleteCourse(courseId);
    }

    //----

    @DeleteMapping(path = "/delete/appointment/{cid}/{sid}")
    public void deleteAppointment(@PathVariable("cid") Long courseId, @PathVariable("sid") Long studentId) {
        teacherService.deleteAppointment(courseId, studentId);
    }
}
