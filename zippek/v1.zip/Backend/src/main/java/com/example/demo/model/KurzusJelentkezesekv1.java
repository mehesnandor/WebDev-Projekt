package com.example.demo.model;

import jakarta.persistence.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table

@ToString
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class KurzusJelentkezesekv1 {

    //@Valid

    @Id
    @SequenceGenerator(
            name = "CourseAppointment_seq",
            sequenceName = "CourseAppointment_seq",
            allocationSize = 1
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "CourseAppointment_seq"
    )

    @Positive
    private Long C_A_ID;

    @NotNull(message = "The Course's Name can not be NULL!")
    @NotEmpty(message = "The Course's Name can not be Empty!")
    @NotBlank(message = "The Course's Name can not be Blank!")
    @Size(min = 1, max = 100, message = "The characters cant be more than 100 or less than 1!")
    private String C_Name;

    @Size(min = 0, max = 254, message = "The description can not be biger than 254 character!")
    private String Description;


    @NotNull(message = "The Teacher's Name can not be NULL!")
    @NotEmpty(message = "The Teacher's Name can not be Empty!")
    @NotBlank(message = "The Teacher's Name can not be Blank!")
    @Size(min = 1, max = 100, message = "The characters can not be more than 100 or less than 1!")
    private String Teacher_Name;

    @Positive
    private Integer Capacity;

    private LocalDateTime Start_Date;

    @Positive
    private Integer Duration;


    @NotNull(message = "The Student's Name can not be NULL!")
    @NotEmpty(message = "The Student's Name can not be Empty!")
    @NotBlank(message = "The Student's Name can not be Blank!")
    @Size(min = 1, max = 100, message = "The characters can not be more than 100 or less than 1!")
    private String Student_Name;

    // Nezz utanna hogy hpogyan validalnak Emailt es Phone-t

    @NotNull(message = "The Email can not be NULL!")
    @NotEmpty(message = "The Email can not be Empty!")
    @NotBlank(message = "The Email can not be Blank!")
    @Size(min = 5, max = 100, message = "The characters can not be more than 100 or less than 1!")
    //@Pattern()
    @Email
    private String Student_Email;


    @NotNull(message = "The Phone number can not be NULL!")
    @NotEmpty(message = "The Phone number can not be Empty!")
    @NotBlank(message = "The Phone number can not be Blank!")
    @Size(min = 3, max = 100, message = "The characters can not be more than 100 or less than 1!")
    //@Pattern()
    private String Student_Phone;



    //AllArgsWithoutIdConstructor
    public KurzusJelentkezesekv1(String cname, String description, String teacher_name, Integer capacity, LocalDateTime sdate, Integer dur, String student_name, String student_email, String phone) {
        this.C_Name = cname;
        this.Description = description;
        this.Teacher_Name = teacher_name;
        this.Capacity = capacity;
        this.Start_Date = sdate;
        this.Duration = dur;
        this.Student_Name = student_name;
        this.Student_Email = student_email;
        this.Student_Phone = phone;
    }

}
