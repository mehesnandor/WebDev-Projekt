package com.example.demo.repo;

import com.example.demo.model.KurzusJelentkezesekv1;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface KurzusJelentkezesekv1Repo extends JpaRepository<KurzusJelentkezesekv1, Long> {

        //Át kell irni, hogy a Star_Date-et is használva határozzon meg egy adott kurzust (Egy tanár egy adott időben csak egy kurzuson lehet. Elv alapján)
    @Query("SELECT k FROM KurzusJelentkezesekv1 k WHERE k.C_Name = ?1 AND k.Teacher_Name = ?2 ")
    Optional<KurzusJelentkezesekv1> findByCourse_NameAndTeacher_Name(String cname, String tname);

    //

    @Query("SELECT k FROM KurzusJelentkezesekv1 k WHERE k.Student_Email = ?1")
    Optional<KurzusJelentkezesekv1> findByEmail(String email);

    @Query("SELECT k FROM KurzusJelentkezesekv1 k WHERE k.Student_Phone = ?1")
    Optional<KurzusJelentkezesekv1> findByPhone(String phone);

    @Query("SELECT k FROM KurzusJelentkezesekv1 k WHERE k.Student_Email = ?1 AND k.Student_Phone = ?2 ")
    Optional<KurzusJelentkezesekv1> findByEmailAndPhone(String email, String phone);

    @Query("SELECT k FROM KurzusJelentkezesekv1 k WHERE k.Student_Email = ?1 OR k.Student_Phone = ?2 ")
    Optional<KurzusJelentkezesekv1> findByEmailOrPhone(String email, String phone);

    //Negáltak

    @Query("SELECT k FROM KurzusJelentkezesekv1 k WHERE k.Student_Email != ?1")
    Optional<KurzusJelentkezesekv1> findByNotEmail(String email);

    @Query("SELECT k FROM KurzusJelentkezesekv1 k WHERE k.Student_Phone != ?1")
    Optional<KurzusJelentkezesekv1> findByNotPhone(String phone);

    @Query("SELECT k FROM KurzusJelentkezesekv1 k WHERE k.Student_Email != ?1 AND k.Student_Phone != ?2 ")
    Optional<KurzusJelentkezesekv1> findByNotEmailAndNotPhone(String email, String phone);

    @Query("SELECT k FROM KurzusJelentkezesekv1 k WHERE k.Student_Email != ?1 OR k.Student_Phone != ?2 ")
    Optional<KurzusJelentkezesekv1> findByNotEmailOrNotPhone(String email, String phone);
}
