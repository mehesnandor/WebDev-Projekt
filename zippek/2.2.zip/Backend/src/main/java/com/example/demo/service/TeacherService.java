package com.example.demo.service;

import com.example.demo.model.Courses;
import com.example.demo.model.Users;
import com.example.demo.repo.CoursesRepo;
import com.example.demo.repo.UsersRepo;
import com.example.demo.service.validation.CourseDetailsValidator;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
@Data
@Slf4j
public class TeacherService implements TearchersServicesInt{

    @Autowired
    private final CourseDetailsValidator courseDetailsValidator;

    @Autowired
    private final UsersRepo usersRepo;

    @Autowired
    private final CoursesRepo coursesRepo;

    /**
     * Listázza a tanárhoz tartozó kurzusokat
     * */

    @Override
    public ResponseEntity<List<Courses>> listOfMyCourses(Long teacherId) {

        if (usersRepo.findById(teacherId).isEmpty()) { // Bár ez elvileg nem kéne előforduljon, mert ő már be van jelentkezve ehez, vagyis tudjuk az adatait és létezett egy bejelentkezésig legalább
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        Users teacher = usersRepo.findById(teacherId).get();
        return ResponseEntity.status(HttpStatus.OK).body(teacher.getTeacherCourses());
    }

    /**
     * Menti az adatbázisba a kurzust
     * */

    @Override
    public ResponseEntity<Courses> saveCourse(Courses course) {

        if (!courseDetailsValidator.isCourseDetailsValid(course)){
            log.error("[Services] Incorect course details! " + course);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }

        Users teacher = course.getTeacher(); // A teacher adatai is jön vele

        if (coursesRepo.existsByCourseName(course.getCourseName())) { // remélem jól működik exist-el, ha nem akkor find-olunk
            log.error("[Teacher-Controller] Course with this name ( " + course.getCourseName() + " ) already exists");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }

        teacher.setTeacherCourses(List.of(course));
        usersRepo.save(teacher);
        log.info("[Teacher-Services] Saving the course to the Teacher's list: " + teacher.getTeacherCourses());

        log.info("[Teacher-Services] Setting the teacher (" + teacher + ") to the course: " + course);
        course.setTeacher(teacher);

        log.info("[Teacher-Services] Saving a course: " + course);
        return ResponseEntity.status(HttpStatus.OK).body(coursesRepo.save(course));
    }

    /**
     * Listázza a kurzus adatait
     * */

    @Override
    public ResponseEntity<Courses> detailsOfACourse(Long courseId) {

        if (coursesRepo.findById(courseId).isEmpty()) {
            log.error("[Teacher-Controller] Course with this id does not exist");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        log.info("[Teacher-Services] Details of the course with ID " + courseId);
        return ResponseEntity.status(HttpStatus.OK).body(coursesRepo.findById(courseId).get());
    }

    /**
     * Listázza a kurzushoz tartozó tanulókat
     * */

    @Override
    public ResponseEntity<List<Users>> appointmentsForThisCourse(Long courseId) {

        if (coursesRepo.findById(courseId).isEmpty()) {
            log.error("[Teacher-Services] Course with ID " + courseId + " does not exist");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        log.info("[Teacher-Services] Listing appointments for course with course ID " + courseId);
        return ResponseEntity.status(HttpStatus.OK).body(coursesRepo.findById(courseId).get().getStudentsList());
    }

    /**
     * Frisiti egy kurzus adatait
     * */

    @Override
    public ResponseEntity<?> updateThisCourse(Courses course) {

        if (!courseDetailsValidator.isCourseDetailsValid(course)){
            log.error("[Services] Incorect course details! " + course);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }

        log.info("[Teacher-Services] Updating the course " + course);
        return ResponseEntity.status(HttpStatus.OK).body(coursesRepo.save(course));
    }

    /**
     * Töröl egy kurzust
     * */

    @Override
    public ResponseEntity<?> deleteCourse(Long courseId) {

        log.info("[Teacher-Services] Deleting the course with ID " + courseId);

        if (coursesRepo.findById(courseId).isEmpty()) {
            log.error("[Teacher-Services] Course with ID " + courseId + " does not exist");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        Courses course = coursesRepo.findById(courseId).get();

        log.info("[Teacher-Services] Deleting the course " + course);

        List<Users> students_appointments = appointmentsForThisCourse(courseId).getBody();

        log.info("[Teacher-Services] Appointments: " + students_appointments);

        for (Users user : students_appointments) {
            user.getUser_appointments().remove(course);
            usersRepo.save(user);
            course.getStudentsList().remove(user); // stb stb ... Bár szerintem nincs ertelme mert megoli ay obiektumot es visyi vele ayt a reszt is
        }

        log.info("[Teacher-Services] Deleting the appointments of course with id " + courseId);

        coursesRepo.delete(course);

        log.info("[Teacher-Services] Deleted the course with " + course);

        return ResponseEntity.status(HttpStatus.OK).build();

    }

    /**
     * Töröl egy jelentkezést a kurzusról
     * */

    @Override
    public ResponseEntity<?> deleteAppointment(Long courseId, Long studentId) {

        log.info("[Teacher-Services] Deleting appointment with course ID " + courseId + " and student ID " + studentId);

        if (usersRepo.findById(studentId).isEmpty()){
            log.error("[Teacher-Services] Student with id " + studentId + " not found");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        Users student = usersRepo.findById(studentId).get();

        if (coursesRepo.findById(courseId).isEmpty()){
            log.error("[Teacher-Services] Course with id " + courseId + " not found");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        Courses course = coursesRepo.findById(courseId).get();

        log.info("[Teacher-Services] Deleting appointment with found course " + course + " and found student " + student);

        student.getUser_appointments().remove(course);
        course.getStudentsList().remove(student);

        log.info("[Teacher-Services] Deleted appointment with course " + course + " and student " + student);

        coursesRepo.save(course);
        usersRepo.save(student);

        return ResponseEntity.status(HttpStatus.OK).build();
    }
}
