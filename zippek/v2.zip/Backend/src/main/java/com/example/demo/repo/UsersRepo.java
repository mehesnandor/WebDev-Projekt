package com.example.demo.repo;

import com.example.demo.model.Users;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsersRepo extends JpaRepository<Users, Long> {

    Users findByUsername(String username);
    //By email
    //ha nincs elore haladas a contact es a Usert osszevonjuk

}
