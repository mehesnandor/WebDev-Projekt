package com.example.demo.service;

import com.example.demo.model.Courses;
import com.example.demo.model.Users;

import java.util.List;

public interface TearchersServicesInt {
    //Create
    void saveCourse(Courses course);

    //Read
    Courses detailsOfACourse(Long courseId);
    List<Users> appointmentsForThisCourse(Long courseId); // Hogyan kell JPA kapcsolatot csinálni, hogy lekérdezzem az Appointmenteket???
    List<Courses> listOfMyCourses(Long teacherId);

    //Update
    void updateThisCourse(Long courseId, Courses course); //vagy nem tudom

    //Delete
    void deleteCourse(Long courseId);
    void deleteAppointment(Long courseId, Long studentId);

}
