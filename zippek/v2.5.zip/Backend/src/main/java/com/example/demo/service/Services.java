package com.example.demo.service;


import com.example.demo.model.Courses;
import com.example.demo.model.Users;
import com.example.demo.repo.ContactsRepo;
import com.example.demo.repo.CoursesRepo;
import com.example.demo.repo.UsersRepo;
import com.example.demo.security.JWTService;
import com.example.demo.service.validation.AppUserDetailsValidator;
import io.swagger.v3.oas.annotations.Operation;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@Data
@Slf4j
public class Services implements ServicesInterface {

    @Autowired
    private final AuthenticationManager authManager;

    @Autowired
    private final JWTService jwtService;

    @Autowired
    private final AppUserDetailsValidator appUserDetailsValidator;

    @Autowired
    private final TeacherService teacherService;

    @Autowired
    private final UsersRepo usersRepo;

    @Autowired
    private final CoursesRepo coursesRepo;

    @Autowired
    private final ContactsRepo contactsRepo;

    /**
     * Felhasználó regisztrálása
     * */

    @Override
    public ResponseEntity<Users> register(Users user){

        if (!appUserDetailsValidator.isUserDetailsValid(user)){
            log.error("[Services] Incorect user details! " + user);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }

        user.setPassword(new BCryptPasswordEncoder(12).encode(user.getPassword()));
        log.info("[Services] Registering a new contact for user " + user.getUsername() + " .  The contacts are " + user.getContact());
        contactsRepo.save(user.getContact());
        log.info("[Services] Registering a new user " + user);
        return ResponseEntity.status(HttpStatus.OK).body(usersRepo.save(user).getData());
    }

    /**
     * Felhasználói adatok lekérdezése
     * */

    @Override
    public ResponseEntity<Users> getUserDataByUsername(String username) {

        if (usersRepo.findByUsername(username) != null) {
            log.info("[Services] Get User Data By Username" + username);
            return ResponseEntity.status(HttpStatus.OK).body(usersRepo.findByUsername(username).getData());
        }

        log.error("[Controller] User Data for " + username + " not found");
        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();

    }

    /**
     * Felhasználó frissitése
     * Passwordot nem lehet változtatni!
     * */

    @Override
    public ResponseEntity<Users> updateUserData(Users user) {

        if (user.getContact() != null) {
            if (!appUserDetailsValidator.isContactDetailsValid(user.getContact())){
                log.error("[Services] Incorect contact details! " + user);
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
            }
            log.info("[Services] Registering a new contact for user " + user.getUsername() + " .  The contacts are " + user.getContact());
            contactsRepo.save(user.getContact());
        }

        log.info("[Services] Updating user data for " + usersRepo.findById(user.getUserId()) + " to " + user);

        user.setPassword(usersRepo.findById(user.getUserId()).get().getPassword()); // Nincs Password módositás! Majd az adminnál vagy eggyáltalán nem

        if (!user.getTeacherCourses().isEmpty()){
            for (Courses course : user.getTeacherCourses()){
                course.setTeacher(user); //mert ha van kurzus hozzá az azt jelenti ő egy tanár
                coursesRepo.save(course);
            }
        }

        log.info("[Services] Registering a new user " + user);
        return ResponseEntity.status(HttpStatus.CREATED).body(usersRepo.save(user).getData());
    }

    /**
     * Felhasználó törlése
     * */

    @Override
    public ResponseEntity<?> deleteUserAccount(String username) {

        if (usersRepo.findByUsername(username) != null) {

            Users user = usersRepo.findByUsername(username);

            log.info("[Services] Deleting user: " + user);

            // Töröli a kapcsolódó `Courses` rekordokat
            for (Courses course : user.getTeacherCourses()) {
                course.setTeacher(null);
                coursesRepo.save(course);
            }

            // Töröld a felhasználóhoz kapcsolódó találkozókat
            for (Courses appointment : user.getUser_appointments()) {
                teacherService.deleteAppointment(user.getUserId(), appointment.getCourseId());
            }

            // Töröli a kapcsolati adatokat
            if (user.getContact() != null) {
                log.info("[Services] Deleting contact " + user.getContact());
                contactsRepo.delete(user.getContact());
            }

            // Töröli a felhasználót
            usersRepo.delete(user);

            return ResponseEntity.status(HttpStatus.OK).build();

        }

        log.info("[Services] User Data for " + username + "not found");
        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }


    /**
     *  Felhasználói adatok ellenőrzése bejelentkezéshez
     *  Flehasználó név és jelszó megadásával az authentifikációs kezelő eleinte httpBasic mód megpróbálja authentifikálni a felhasználót, amenyiben nincsen JWT Tokene (Ez a rész a SecurityConfig file JWTFilter részénél található). Sikeres authentifikáció esetén generál egy JWT Tokent, amit vissza ad.
     * */

    public String verify(Users user){

        log.info("[Services] Verifying user data: " + user.toString());

        Authentication auth = authManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        user.getUsername(),
                        user.getPassword()
                )
        );

        if (auth.isAuthenticated()){
            log.info("[Services] Is Authentificated:  " + auth.isAuthenticated());
            log.info("[Services] Principals: " + auth.getPrincipal() + " Username: " + user.getUsername());
            log.info("[Services] Sikeres JWT Token authentifikáció");
            return jwtService.generateToken(user.getUsername());
        }

        log.error("[Services] Sikertelen authentifikáció");
        return "Field to authenticate";

    }

}
