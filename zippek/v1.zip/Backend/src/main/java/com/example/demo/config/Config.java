package com.example.demo.config;

import com.example.demo.model.KurzusJelentkezesekv1;
import com.example.demo.repo.KurzusJelentkezesekv1Repo;
import lombok.Data;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDateTime;


@Configuration
@Data
public class Config {

    private final KurzusJelentkezesekv1Repo kRepo;

    //Old meg "Miért nem mennek végbe a tranzakciók?"

    @Bean
    CommandLineRunner commandLineRunner() {
        return args -> {
            kRepo.save(
                    new KurzusJelentkezesekv1(
                            1L,
                            "Java Kurzus",
                            "Hat, ez egz test szoval semmi erdekes nincs itt.",
                            "Veronica Palovsci",
                            5,
                            LocalDateTime.now(),
                            30,
                            "CicaRagoStudent",
                            "Buzivagzok@geci.com",
                            "+36 5357 872 538"
                    )
            );

            /*
            * MI az amit a gép generál ezen a verzión belül?
            * Attributumok:
            *
            *   - C_A_ID        -> By DB                            in the DB
            *
            * Frontend csak a kliens adatokat küldi és azzal hozzuk létre, ami egsyszerübb
            *
            *   - C_Name        -> By Hard Coded
            *   - Description   -> Nothing for now
            *   - Teacher_Name  -> "Xerone Yelorica" just for now
            *   - Capacity      -> random number btw(5, 30)
            *   - Start_Date    -> random date btw(now, +5day)
            *   - Duration      -> random number btw(15, 120)
            *
            *
            * // A többit egy formon keresztül megadhatja a felhasználó
            *
            *   - Student_Name
            *   - Student_Email
            *   - Student_Phone
            * */


            kRepo.save(
                    new KurzusJelentkezesekv1(
                            "Java Kurzus",
                            "Test",
                            "Celensci Zsuzsanna",
                            15,
                            LocalDateTime.now(),
                            60,
                            "CicaRagoStudent",
                            "Buzivagzok@geci.com",
                            "+36 5357 872 538"
                    )
            );
            kRepo.save(
                    new KurzusJelentkezesekv1(
                            "Html Kurzus",
                            "test",
                            "Veronica Palovsci",
                            1,
                            LocalDateTime.now(),
                            300,
                            "CicaRagoStudent",
                            "Buzivagzok@geci.com",
                            "+36 5357 872 538"
                    )
            );
        };
    }

}
