package com.example.demo.service;

import com.example.demo.model.Courses;
import com.example.demo.model.Users;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TeacherService implements TearchersServicesInt{
    @Override
    public List<Courses> listOfMyCourses(Long teacherId) {
        return List.of();
    }

    @Override
    public void saveCourse(Courses course) {

    }

    @Override
    public Courses detailsOfACourse(Long courseId) {
        return null;
    }

    @Override
    public List<Users> appointmentsForThisCourse(Long courseId) {
        return List.of();
    }

    @Override
    public void updateThisCourse(Long courseId, Courses course) {

    }

    @Override
    public void deleteCourse(Long courseId) {

    }

    @Override
    public void deleteAppointment(Long courseId, Long studentId) {

    }
}
