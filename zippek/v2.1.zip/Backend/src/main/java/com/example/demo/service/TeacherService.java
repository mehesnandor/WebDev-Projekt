package com.example.demo.service;

import com.example.demo.model.Courses;
import com.example.demo.model.Users;
import com.example.demo.repo.CoursesRepo;
import com.example.demo.repo.UsersRepo;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
@Data
@Slf4j
public class TeacherService implements TearchersServicesInt{

    @Autowired
    private final UsersRepo usersRepo;

    @Autowired
    private final CoursesRepo coursesRepo;

    /**
     * Listázza a tanárhoz tartozó kurzusokat
     * */

    @Override
    public List<Courses> listOfMyCourses(Long teacherId) {

        if (usersRepo.findById(teacherId).isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found");
        }

        Users teacher = usersRepo.findById(teacherId).get();
        return teacher.getTeacherCourses();
    }

    /**
     * Menti az adatbázisba a kurzust
     * */

    @Override
    public Courses saveCourse(Courses course) {

        Users teacher = course.getTeacher();

        if (coursesRepo.existsByCourseName(course.getCourseName())) {
            log.error("[Teacher-Controller] Course with this name ( " + course.getCourseName() + " ) already exists");
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "[Teacher-Controller] Course with this name ( " + course.getCourseName() + " ) already exists");
        }

        teacher.setTeacherCourses(List.of(course));
        usersRepo.save(teacher);
        log.info("[Teacher-Services] Saving the course to the Teacher's list: " + teacher.getTeacherCourses());

        log.info("[Teacher-Services] Setting the teacher (" + teacher + ") to the course: " + course);
        course.setTeacher(teacher);

        log.info("[Teacher-Services] Saving a course: " + course);
        return coursesRepo.save(course);
    }

    /**
     * Listázza a kurzus adatait
     * */

    @Override
    public Courses detailsOfACourse(Long courseId) {

        if (coursesRepo.findById(courseId).isEmpty()) {
            log.error("[Teacher-Controller] Course with this id does not exist");
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Course with this id does not exist");
        }

        log.info("[Teacher-Services] Details of the course with ID " + courseId);
        return coursesRepo.findById(courseId).get();
    }

    /**
     * Listázza a kurzushoz tartozó tanulókat
     * */

    @Override
    public List<Users> appointmentsForThisCourse(Long courseId) {

        if (coursesRepo.findById(courseId).isEmpty()) {
            log.error("[Teacher-Services] Course with ID " + courseId + " does not exist");
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Course with ID " + courseId + " does not exist");
        }

        log.info("[Teacher-Services] Listing appointments for course with course ID " + courseId);
        return coursesRepo.findById(courseId).get().getStudentsList();
    }

    /**
     * Frisiti egy kurzus adatait
     * */

    @Override
    public void updateThisCourse(Courses course) {
        coursesRepo.save(course);
        log.info("[Teacher-Services] Updating the course " + course);
    }

    /**
     * Töröl egy kurzust
     * */

    @Override
    public void deleteCourse(Long courseId) {

        log.info("[Teacher-Services] Deleting the course with ID " + courseId);

        Courses course = coursesRepo.findById(courseId)
                .orElseThrow(() -> {
                    log.error("[Teacher-Services] Course with id " + courseId + " not found");
                    return new RuntimeException("Course not found");
                });

        log.info("[Teacher-Services] Deleting the course " + course);

        List<Users> students_appointments = appointmentsForThisCourse(courseId);

        log.info("[Teacher-Services] Appointments: " + students_appointments);

        for (Users user : students_appointments) {
            user.getUser_appointments().remove(course);
            usersRepo.save(user);
            //course.getStudentsList().remove(user); stb stb ... Szerintem nincs ertelme mert megoli ay obiektumot es visyi vele ayt a reszt is
        }

        log.info("[Teacher-Services] Deleting the appointments of course with id " + courseId);

        coursesRepo.delete(course);

        log.info("[Teacher-Services] Deleted the course with " + course);

    }

    /**
     * Töröl egy jelentkezést a kurzusról
     * */

    @Override
    public void deleteAppointment(Long courseId, Long studentId) {
        log.info("[Teacher-Services] Deleting appointment with course ID " + courseId + " and student ID " + studentId);
        Users student = usersRepo.findById(studentId)
                .orElseThrow(() -> {
                    log.error("[Teacher-Services] Student with id " + studentId + " not found");
                    return new RuntimeException("Student not found");
                });

        Courses course = coursesRepo.findById(courseId)
                .orElseThrow(() -> {
                    log.error("[Teacher-Services] Course with id " + courseId + " not found");
                    return new RuntimeException("Course not found");
                });

        log.info("[Teacher-Services] Deleting appointment with found course " + course + " and found student " + student);

        student.getUser_appointments().remove(course);
        course.getStudentsList().remove(student);

        log.info("[Teacher-Services] Deleted appointment with course " + course + " and student " + student);

        coursesRepo.save(course);
        usersRepo.save(student);
    }
}
