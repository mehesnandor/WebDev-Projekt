package com.example.demo.config;

import com.example.demo.model.Contacts;
import com.example.demo.model.Courses;
import com.example.demo.model.Roles;
import com.example.demo.model.Users;
import com.example.demo.repo.ContactsRepo;
import com.example.demo.repo.CoursesRepo;
import com.example.demo.repo.UsersRepo;
import com.example.demo.service.AdminService;
import com.example.demo.service.Services;
import com.example.demo.service.StudentService;
import com.example.demo.service.TeacherService;
import com.example.demo.service.validation.AppUserDetailsValidator;
import com.example.demo.service.validation.CourseDetailsValidator;
import com.example.demo.service.validation.PasswordValidator;
import com.github.javafaker.Faker;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;


@Configuration
@RequiredArgsConstructor
public class Config {

    //Services

    @Autowired
    private final Services services;

    @Autowired
    private final TeacherService teacherService;

    @Autowired
    private final AdminService adminService;

    @Autowired
    private final StudentService studentService;

    // Validatorok

    @Autowired
    private final AppUserDetailsValidator appUserDetailsValidator;

    @Autowired
    private final CourseDetailsValidator courseDetailsValidator;

    // Repos

    @Autowired
    private final CoursesRepo coursesRepo;

    @Autowired
    private final UsersRepo usersRepo;

    @Autowired
    private final ContactsRepo contactsRepo;

    // -----

    @Bean
    CommandLineRunner commandLineRunner() {
        return args -> {

            LocalDateTime now = LocalDateTime.now();

            Users user1 = new Users(
                    "T",
                    "Aa12345!",
                    Roles.TEACHER
            );

            Users user2 = new Users(
                    "S",
                    "Aa12345!",
                    Roles.STUDENT
            );

            Users user3 = new Users(
                    "A",
                    "Aa12345!",
                    Roles.ADMIN
            );

            services.register(user1);
            services.register(user2);
            services.register(user3);



            Faker faker = new Faker();

            // Users

            for (int i = 0; i < 10; i++) { // X mennyiségü felhasználó generálás a registráción keresztül
                services.register(validUserGenerator());
            }

            for (int i = 0; i < 10; i++) { // X mennyiségü felhasználó generálás a Admin által
                adminService.createUser(validUserGenerator());
            }

            // Courses

            for (int i = 0; i < 10; i++) { // X mennyiségü kuryus generálás Teacher által

                List<Users> teachers = usersRepo.findByRole(Roles.TEACHER);

                for (Users teacher : teachers) {

                    int k = faker.number().numberBetween(0, 2);

                    for (int j = 0; j < k; j++) {
                        Courses course = validCourseGenerator();
                        course.setTeacher(teacher);
                        teacherService.saveCourse(course);
                    }

                }

            }

            for (int i = 0; i < 10; i++) { // X mennyiségü kuryus generálás Admin által

                List<Users> teachers = usersRepo.findByRole(Roles.TEACHER);

                for (Users teacher : teachers) {

                    int k = faker.number().numberBetween(0, 1);

                    for (int j = 0; j < k; j++) {
                        Courses course = validCourseGenerator();
                        course.setTeacher(teacher);
                        adminService.createCourse(course);
                    }

                }

            }

            // Appointments

            makeSomeAppointments();

            System.out.println("[Config] Test Data Insertion are done! Started at: " + now + " finished at: " + LocalDateTime.now() + ". Duration: " + getDuration(now, LocalDateTime.now()));

        };
    }

    public Integer getDuration(LocalDateTime start, LocalDateTime end) {
        return (int) ChronoUnit.SECONDS.between(start, end);
    }


    public Users validUserGenerator(){

        Faker faker = new Faker();

        String username = faker.name().username();
        while(!appUserDetailsValidator.isNotExistsUsersUsername(username)){
            username = faker.name().username();
        }
        System.out.println(username);

        String password = faker.regexify("[a-zA-Z0-9!@#$%^&*()]{8,16}"); //faker.regexify("(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[@#$%^&+=]).{8,12}");  // Data truncation: Data too long for column 'password' at row 1 - Nana
        while(PasswordValidator.isValidPassword(password)){
            password = faker.regexify("[a-zA-Z0-9!@#$%^&*()]{8,16}");
        }
        System.out.println(password);

        Roles role = faker.options().option(Roles.class);

        System.out.println(role);

        String email = faker.internet().emailAddress();
        while(!appUserDetailsValidator.isNotExistsContactEmail(email)){
            email = faker.internet().emailAddress();
        }
        System.out.println(email);

        String phone = faker.regexify("(\\+\\d{1,3}[- ]?)?\\d{10}");
        while(!appUserDetailsValidator.isNotExistsContactPhone(phone)){
            phone = faker.regexify("(\\+\\d{1,3}[- ]?)?\\d{10}");
        }

        System.out.println(phone);

        Users user = new Users(
                username,
                password,
                role,
                new Contacts(
                        email,
                        phone
                )
        );

        System.out.println(user);

        return user;

    }

    public Courses validCourseGenerator(){

        Faker faker = new Faker();

        String courseName = faker.name().title();
        while (!courseDetailsValidator.isNotSameCourseName(courseName)) {
            courseName = faker.name().title();
        }

        String courseDescription = faker.lorem().characters(250);

        Integer capacity = faker.number().numberBetween(1, 50);

        LocalDateTime startDate = faker.date().between(
                Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant()),
                Date.from(LocalDateTime.now().plusMonths(2).atZone(ZoneId.systemDefault()).toInstant())
        ).toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();

        LocalDateTime endDate = faker.date().between(
                Date.from(LocalDateTime.now().plusMonths(2).atZone(ZoneId.systemDefault()).toInstant()),
                Date.from(LocalDateTime.now().plusMonths(3).atZone(ZoneId.systemDefault()).toInstant())
        ).toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();

        return new Courses(
                courseName,
                courseDescription,
                capacity,
                startDate,
                endDate
        );
    }

    public void makeSomeAppointments() {

        Faker faker = new Faker();

        List<Users> students = usersRepo.findByRole(Roles.STUDENT);
        List<Courses> courses = coursesRepo.findAll();

        for (Users user : students) {

            int f = faker.number().numberBetween(0, courses.size());

            for (int j = 0; j < f; j++) {
                Courses course = courses.get(faker.random().nextInt(courses.size()));
                courses.remove(course);

                user.setUser_appointments(courses);
                usersRepo.save(user);

                course.setStudentsList(List.of(user));
                coursesRepo.save(course);
            }

        }
    }


}
